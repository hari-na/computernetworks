# Bully

class process:
    def __init__(self, id, priority,active=True):
        self.id = id
        self.priority = priority
        self.active = active

def bully():
    n = int(input("Enter number of processes: "))
    processes = []
    for i in range(n):
        id = int(input("Enter process id: "))
        priority = int(input("Enter process priority: "))
        active = int(input("Enter process status (0 or 1): "))
        processes.append(process(id, priority,active))

    processes.sort(key=lambda x : x.priority, reverse=True)

    while True:
        start = int(input("Enter starting process: "))
        print("Election Begins")

        if start not in [x.id for x in processes]:
            print("Invalid starting process")
            break

        else:
            arr=[start]
            while len(arr)!=0:
                flag=0
                start = arr.pop(-1)
                for i in range(len(processes)):
                    if processes[i].id == start:
                        index=i
                for i in range(index-1, -1, -1):
                    if processes[i].active:
                        arr.append(processes[i].id)
                        flag = 1
                if flag==0:
                    coordinator = start
                    break

                arr.sort(reverse=True)
            
            print("Election Ends")
            print("Coordinator is process "+str(coordinator))

            print("Do you want to continue? (y/n)")
            status = input()
            if status=='n':
                break
            else:
                print("Enter the process to crash: ")
                crash = int(input())
                for i in range(len(processes)):
                    if processes[i].id == crash:
                        processes[i].active = False
                        break

bully()

# Ring

n = int(input("Enter no of processes:"))
processes = []
status = []
for i in range(n):
	process_id=int(input("Enter the process id:"))
	status_id=int(input("Enter the status of the process:"))	
	processes.append(process_id)
	status.append(status_id)

print("Processes       Status")
for i in range(n):
	print(processes[i],'             ',status[i])

print("The current co-ordinator is:", max(processes), "\n")

end = int(input("Enter the processes which fails:"))
fail = processes.index(end)
status[fail] = 0

print("The failed processor is:", end, "\n")

start = int(input("Enter the process which initiates the election:"))

def election():
    arr=[]
    for i in range(n):
        if start == processes[i]:
            index = i
            break
    next = (index+1)%n
    while processes[index] != start or len(arr)==0:
        if(status[index]==1 and status[next]==0):
            print("Election messages is sent from ", processes[(index)], "to ", processes[(next)], "\n")
            print("!!! No response from ", processes[(next)], "to ", processes[(index)], "\n")
            next=(next+1)%n
        elif(status[index]==1 and status[next]==1):
            print("Election messages is sent from ", processes[(index)], "to ", processes[(next)], "\n")
            print("$$$ Response message from ", processes[(next)], "to ", processes[(index)], "\n")
            arr.append(processes[index])
            index=next
            next=(next+1)%n

    print("After the election, new coordinator is:", max(arr), "\n")

election()